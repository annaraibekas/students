import {createStackNavigator} from 'react-navigation-stack';
import {createAppContainer } from 'react-navigation';

import Start from '../screens/launge';
import Second from '../screens/welcome';
import Third from '../screens/Login';
import Fourth from '../screens/Register';

const stackNavigatorOptions = { headerShown:false}

const AppNavigator = createStackNavigator({
     Start: Start,
     SecondScreen: {
       screen: Second
     } ,
     'Third Screen': Third,
     FourthScreen: { screen: Fourth},
},
{
  defaultNavigationOptions: stackNavigatorOptions
}
);

export default createAppContainer(AppNavigator);