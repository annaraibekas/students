 
import React, {useState} from 'react';  
import {StyleSheet, Text, TextInput, Button, View,Image,Dimensions, ImageBackground} from 'react-native'; 


 
 const image = { uri: "https://i.pinimg.com/736x/89/16/82/8916827db56cae6c6cb4799c2a479ffd.jpg" };
 
 const Third = props => {
const [number, onChangeNumber] = React.useState(null);
const [text, onChangeText] = React.useState(null);
   
 return (  
        <View style={styles.container}>  
       
       <ImageBackground source={image} resizeMode="cover" style={styles.image}>
        <Text style={styles.text}>Sign Up</Text>
        <TextInput
        style={styles.input}
        onChangeText={onChangeText}
        value={text}
        placeholder="user name"
      />
        <TextInput
        style={styles.input}
        onChangeText={onChangeNumber}
        value={number}
        placeholder="password"
        keyboardType="numeric"
      />
      </ImageBackground>
      <View style={styles.butto}> 
         <Button color='black' title="Go Back" onPress={() => {
        props.navigation.popToTop();
      }}/>
      </View>
        </View>  
    );  
  
 
}


const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
         flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center'  
    },  
    image: {
    flex: 1,
    justifyContent: "center",
    width: '100%',
    height: '100%',
  },
  butto: {
      borderColor: 'red',
      position: 'absolute',
      bottom:0,
      right:0,
      left:0, 
      flex: 1,
      justifyContent: "center",   
   },
  butto1: {
      borderColor: 'red',
      position: 'absolute',
      bottom:0,
      left:0, 
      flex: 1,
      justifyContent: "center", 
       width:'49% ',  
   },
   butto2: {
      borderColor: 'red',
      position: 'absolute',
      bottom:0,
      right:0,
      flex: 1,
      justifyContent: "center", 
      width:'49% ',
   },
   text: {
    position: 'absolute',
    top: 0,
    width:'100% ',
    color: "white",
    fontSize: 36,
    lineHeight: 84,
    fontWeight: "bold",
    textAlign: "center",
    //backgroundColor: "#000000c0"
  },
  input: {
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    backgroundColor: "#000000c0",
    color:'white',
  },


});  

export default Third;


