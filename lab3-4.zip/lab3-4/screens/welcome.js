 
import React, {useState} from 'react';  
import {StyleSheet, Text, TextInput, Button, View,Image,Dimensions, ImageBackground} from 'react-native'; 


 
 const image = { uri: "https://s3-symbol-logo.tradingview.com/netflix--600.png" };
 const Second = props => {
function nav(){
      props.navigation.navigate({routeName: 'Third Screen'});
  }

   
 return (  
        <View style={styles.container}>  
       
       <ImageBackground source={image} resizeMode="cover" style={styles.image}>
        <Text style={styles.text}>Netflix and Chill</Text>
      </ImageBackground>
      <View style={styles.butto2}> 
         <Button color='red' title="Third Screen" onPress={nav}/>
         </View>
         <View style={styles.butto1}> 
          <Button color='red' title="Go Back" onPress={() => {
        props.navigation.goBack();
      }}/>
               </View>

        </View>  
    );  
  
 
}


const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
         flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center'  
    },  
    image: {
    flex: 1,
    justifyContent: "center",
    width: '100%',
    height: '100%',
  },
  butto1: {
      borderColor: 'red',
      position: 'absolute',
      bottom:0,
      left:0, 
      flex: 1,
      justifyContent: "center", 
       width:'49% ',  
   },
   butto2: {
      borderColor: 'red',
      position: 'absolute',
      bottom:0,
      right:0,
      flex: 1,
      justifyContent: "center", 
      width:'49% ',
   },
   text: {
    color: "white",
    fontSize: 42,
    lineHeight: 84,
    fontWeight: "bold",
    textAlign: "center",
    backgroundColor: "#000000c0"
  },


});  

export default Second;


