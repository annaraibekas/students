 
import React, {useState} from 'react';  
import {StyleSheet, Text, Button, View, Image, ImageBackground} from 'react-native'; 


 
 const image = { uri: "https://s3-symbol-logo.tradingview.com/netflix--600.png" };
 const Start = props => {

  function nav(){
      props.navigation.navigate({routeName: 'SecondScreen'});
  }

   
 return (  
        <View style={styles.container}>  
       
        <ImageBackground source={image} resizeMode="cover" style={styles.image}>
        
        </ImageBackground>
        <View style={styles.butto}> 
        <Button color='red' title="Second Screen" onPress={nav}/>
        </View>
        </View>  
    );  
  
 
}


const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
         flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center'  
    },  
    tinyLogo: {
    width: 50,
    height: 50,
  },
  image: {
    flex: 1,
    justifyContent: "center",
    width: '100%',
    height: '100%',
  },
  butto: {
      borderColor: 'red',
      position: 'absolute',
      bottom:0,
      right:0,
      left:0, 
      flex: 1,
      justifyContent: "center",   
   },


});  

export default  Start;


