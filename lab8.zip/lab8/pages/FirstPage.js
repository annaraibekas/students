// React Native Pass Value From One Screen to Another Using React Navigation
// https://aboutreact.com/react-native-pass-value-from-one-screen-to-another-using-react-navigation/

import React, {useState} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  View,
  Text,
  TextInput,
  Button,
  ImageBackground,
  Alert,
} from 'react-native';
import Icon from '@expo/vector-icons/AntDesign';

const image = { uri: "https://i.pinimg.com/736x/89/16/82/8916827db56cae6c6cb4799c2a479ffd.jpg" };

const onPressTitle = () => {
    Alert.alert(
  'Password rules',
  'Your password must consist of latin letters and numbers',
  [
    {
      text: 'Cancel',
      onPress: () => console.log('Cancel Pressed'),
      style: 'Cancel'
    },
    {
      text: 'Show Examples',
      onPress: () => console.log('Show Examples')
    }
  ]
);
  };

const onPressTitle_1 = () => {
    
  };

const FirstPage = ({navigation}) => {
  const [userName, setUserName] = useState('AboutReact');
  const [number, onChangeNumber] = React.useState(null);
  const [text, onChangeText] = React.useState(null);

  return (  
        <View style={styles.container}>  
       
       <ImageBackground source={image} resizeMode="cover" style={styles.image}>
       <View style={styles.butto}>
        <Text style={styles.butto} title="INFO" onPress={onPressTitle}>INFO
        </Text>
      </View>
        <Text style={styles.text}>Log in</Text>
        <Text style={styles.text_1}>Enter your login and password</Text>
        <View style={styles.input}>
        <Icon name='mail' color='white' size={24}/>
        <TextInput style={{paddingHorizontal:10, fontFamily:'Regular', color:"white"}}
        onChangeText={onChangeText}
        value={text}
        placeholder="user name"
      />
      </View>
      <View style={styles.input}>
        <Icon name='key' color='white' size={24}/>
        <TextInput
        style={{paddingHorizontal:10, fontFamily:'Regular', color:"white"}}
        onChangeText={onChangeNumber}
        value={number}
        secureTextEntry={true}
        placeholder="password"
        keyboardType="numeric"
      />
      </View>
      <View style={styles.enter_b}>
        <Text style={styles.input1} title="Enter" onPress={() =>
            navigation.navigate('SecondPage', {
              paramKey: text,
            })
          }>ENTER
        </Text>
      </View>
      </ImageBackground>
        </View>  
    );
};

export default FirstPage;

const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
         flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center'  
    },  
    image: {
    flex: 1,
    justifyContent: "center",
    width: '100%',
    height: '100%',
  },
  butto: {
      //borderColor: 'red',
      color: 'white',
      position: 'absolute',
      top: 10,
      bottom:150,
      right:5,
      //left:0, 
      flex: 1,
      justifyContent: "center", 
   },
  butto1: {
      borderColor: 'red',
      position: 'absolute',
      bottom:0,
      left:0, 
      flex: 1,
      justifyContent: "center", 
       width:'49% ',  
   },
   butto2: {
      borderColor: 'red',
      position: 'absolute',
      bottom:0,
      right:0,
      flex: 1,
      justifyContent: "center", 
      width:'49% ',
   },
   enter_b:{
     top: 50,
    height: 50,
    margin: 12,
    padding: 10,
   },
   text: {
    position: 'absolute',
    fontFamily: 'SemiBold',
    top: 40,
    width:'100% ',
    color: "white",
    fontSize: 36,
    lineHeight: 84,
    fontWeight: "bold",
    textAlign: "center",
    //backgroundColor: "#000000c0"
  },
  text_1:{
    top: 120,
    fontFamily:'Medium',
    position: 'absolute',
    width:'100% ',
    color: "white",
    fontSize: 24,
    textAlign: "center",
  },
  input: {
    top: 40,
    flexDirection:'row',
    alignItems:'center',
    height: 50,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    backgroundColor: "#000000c0",
    color:'white',
    fontFamily:'Regular',
  },
  input1: {
    fontFamily:'Regular', 
    height: 40,
    margin: 12,
    borderWidth: 1,
    padding: 10,
    textAlign:'center',
    backgroundColor: "#000000c0",
    color:'white',
  },


});  
