import React from 'react';
import { StyleSheet, Text, ScrollView, Image, View } from 'react-native';
const LotsOfStyles = () => {
return (
<ScrollView style={styles.scrollView}>
<View style={styles.container}>
<Text style={styles.bigBlack}>Журнал Bright</Text>
<Text style={styles.red}>{'\n'}Новости{'\n'}</Text>
<Image
        style={styles.tinyLogo}
        source={{
          uri: 'https://www.mhealth.ru/upload/custom/e86/e86d6efcd6e9ebb5bc31694cf469df00.jpg',
        }}
      />
<Text style={[styles.title_]}>Лучшие мини-сериалы для отпускных вечеров</Text>
<Text style={[styles.smallBlack]}>Летний отпуск – идеальное время для долгих прогулок, созерцания красот природы и долгих разговоров по душам теплыми вечерами. Но для увлекательных сериалов в нем время тоже найдется, но не для тех, которые могут похвастаться бесконечным количеством серий, а для мини-сериалов. Мы выбрали для вас самые захватывающие из них. Устраивайтесь поудобнее и наслаждайтесь! {'\n'}</Text>
<Text style={[styles.title_2]}>Мейр из Исттауна (2021) </Text>
<Text style={[styles.smallBlack2]}>{'\n'}Актриса Кейт Уинслет играет в одном из лучших полицейских мини-сериалов года главную роль. Семь серий погружают нас в мир детектива из маленького городка Пенсильвании, которая расследует местное убийство, пытаясь, выбраться из личных драматических переживаний.  </Text>
<Image
        style={styles.tinyLogo}
        source={{
          uri: 'https://i0.wp.com/itc.ua/wp-content/uploads/2021/06/oblozhka-6.jpg?fit=1280%2C800&quality=100&strip=all&ssl=1',
        }}
      />
<Text style={[styles.title_2]}>{'\n'}Ход королевы (2020)  </Text>
<Text style={[styles.smallBlack2]}>{'\n'}Если вы еще не видели это сериал, влюбивший в себя полмира, то отпуск – лучшее время для этого. Даже если вам не особо интересны шахматы и все, что с ними связано, оторваться от шахматной магии вы точно не сможете. Неудивительно, что после выхода сериала в прошлом году, продажи шахматных досок по всему миру увеличились в разы.  </Text>
<Image
        style={styles.tinyLogo}
        source={{
          uri: 'https://www.game-ost.ru/static/covers_soundtracks/2/9/295104_928771.jpg',
        }}
      />
<Text style={[styles.title_2]}>{'\n'}ВандаВижен (2021)  </Text>
<Text style={[styles.smallBlack2]}>{'\n'}Сериал, сочетающий в себе магию вселенной Marvel и классической комедии. Ванда Максимофф и Вижн — два супергероя, которые живут идиллической жизнью на окраине города. Однажды они начинают подозревать, что не все так идеально, как кажется.  </Text>
<Image
        style={styles.tinyLogo}
        source={{
          uri: 'https://cdn.kanobu.ru/r/82a942e397e53fb07c4caba4ce3880a2/1040x700/u.kanobu.ru/editor/images/85/7c7118bc-6725-473a-80c5-03f8fdde0584.jpg',
        }}
      />

</View>
 </ScrollView>
);
};
const styles = StyleSheet.create({
container: {
marginTop: 50,
justifyContent: 'center',
marginLeft: 10,
marginRight: 10,
},
title_: {
color: 'black',
fontWeight: 'bold',
fontSize: 40,
},
title_2: {
color: 'black',
fontWeight: 'bold',
fontSize: 30,
},
bigBlack: {
color: 'black',
fontWeight: 'bold',
fontSize: 30,
textAlign: "center",
},
smallBlack: {
color: 'black',
fontStyle: 'italic',
fontSize: 20,
},
smallBlack2: {
color: 'black',
fontSize: 15,
},
red: {
color: 'purple',
fontSize: 20,
},
tinyLogo: {
    width: 360,
    height: 240,
    alignSelf: "center",
  },
});
export default LotsOfStyles;