 
import React, {useState, useRef} from 'react';  
import {StyleSheet, Text, TextInput, Button, View,Image,Dimensions, ImageBackground, Animated, ScrollView,  useWindowDimensions} from 'react-native'; 


 
 const image = { uri: "https://s3-symbol-logo.tradingview.com/netflix--600.png" };
 const images = ["https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/game-of-thrones-illustration-sean-longmore-1598631176.jpeg", "https://media.vanityfair.com/photos/5fe583982a41ae5e9066a8ae/master/pass/bridgerton-sexual-assault.jpg", "https://media.timeout.com/images/105803472/750/422/image.jpg", "https://images.immediate.co.uk/production/volatile/sites/3/2021/08/Lucifer_season_6_cast-8338d9f.jpg?quality=90&resize=620,413", "https://pbs.twimg.com/media/E3YZ6C1X0AgWt02.jpg"];

const imtext = ['Game of Thrones', 'Bridgerton', 'Stranger Things', 'Lucifer', 'Shadow and Bone']

 const Second = props => {
   const scrollX = useRef(new Animated.Value(0)).current;
   const { width: windowWidth } = useWindowDimensions();
function nav(){
      props.navigation.navigate({routeName: 'Third Screen'});

      
  }

  return (
    <View style={styles.container}> 
 
      <View style={styles.scrollContainer}>
      
        <ScrollView
          horizontal={true}
          style={styles.scrollViewStyle}
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onScroll={Animated.event([
            {
              nativeEvent: {
                contentOffset: {
                  x: scrollX
                }
              }
            }
          ])}
          scrollEventThrottle={1}
        >
          {images.map((image, imageIndex) => {
            return (
              <View
                style={{ width: windowWidth, height: 250 }}
                key={imtext}>
                <ImageBackground source={{ uri: image }} style={styles.card}>
                    <View style={styles.textContainer}>
                                        <Text style={styles.infoText}>
                      {imtext[imageIndex]}
                    </Text>
                  </View>
                </ImageBackground>
              </View>
            );
          })}
        </ScrollView>

        

        <View style={styles.indicatorContainer}>
          {images.map((image, imageIndex) => {
            const width = scrollX.interpolate({
              inputRange: [
                windowWidth * (imageIndex - 1),
                windowWidth * imageIndex,
                windowWidth * (imageIndex + 1)
              ],
              outputRange: [8, 16, 8],
              extrapolate: "clamp"
            });
            return (
              <Animated.View
                key={imageIndex}
                style={[styles.normalDot, { width }]}
              />
            );
          })}
        </View>
      </View>

      
       
      <View style={styles.container}>  
      <ImageBackground source={image} resizeMode="cover" style={styles.image}>
        <Text style={styles.text}>Netflix and Chill</Text>
      </ImageBackground> 
      <View style={styles.butto2}> 
         <Button color='red' title="Third Screen" onPress={nav}/>
      </View>
         <View style={styles.butto1}> 
          <Button color='red' title="Go Back" onPress={() => {
        props.navigation.goBack();
      }}/>
               </View>

        </View>  
      
    </View>  

  );
}

   
 //return (  
   //     <View style={styles.container}>  
       


       
     //  <ImageBackground source={image} resizeMode="cover" style={styles.image}>
       // <Text style={styles.text}>Netflix and Chill</Text>
//      </ImageBackground>
   //   <View style={styles.butto2}> 
     //    <Button color='red' title="Third Screen" onPress={nav}/>
       //  </View>
         //<View style={styles.butto1}> 
//          <Button color='red' title="Go Back" onPress={() => {
  //      props.navigation.goBack();
    //  }}/>
      //         </View>
//
  //      </View>  
    //);  
  
 
//}


const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
        flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center',
        backgroundColor: 'black', 
        width: '100%',
    },  
    image: {
    flex: 1,
    justifyContent: "center",
    width: '100%',
    height: '100%',
  },
  butto1: {
      borderColor: 'red',
      position: 'absolute',
      bottom:0,
      left:0, 
      flex: 1,
      justifyContent: "center", 
       width:'49% ',  
   },
   butto2: {
      borderColor: 'red',
      position: 'absolute',
      bottom:0,
      right:0,
      flex: 1,
      justifyContent: "center", 
      width:'49% ',
   },
   text: {
    color: "white",
    fontSize: 42,
    lineHeight: 84,
    fontWeight: "bold",
    textAlign: "center",
    backgroundColor: "#000000c0"
  },
    scrollContainer: {
    height: '40%',
    alignItems: "center",
    justifyContent: "center"
  },
  card: {
    flex: 1,
    marginVertical: 4,
    marginHorizontal: 16,
    borderRadius: 5,
    overflow: "hidden",
    alignItems: "center",
    justifyContent: "center"
  },
    textContainer: {
    backgroundColor: "rgba(0,0,0, 0.7)",
    paddingHorizontal: 24,
    paddingVertical: 8,
    borderRadius: 5
      },
  infoText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold"
  },
  normalDot: {
    height: 8,
    width: 8,
    borderRadius: 4,
    backgroundColor: "silver",
    marginHorizontal: 4
  },
  indicatorContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center"
  },


});  

export default Second;


