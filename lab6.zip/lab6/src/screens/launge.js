 
import React, {useState, useRef, useEffect} from 'react'; 
import {StyleSheet, Text, Button, View, Image, ImageBackground, Animated} from 'react-native'; 


 
 const image = { uri: "https://s3-symbol-logo.tradingview.com/netflix--600.png" };

const FadeInView = (props) => {
  const fadeAnim = useRef(new Animated.Value(0)).current  // Initial value for opacity: 0

  React.useEffect(() => {
    Animated.timing(
      fadeAnim,
      {
        toValue: 1,
        duration: 1000,
      }
    ).start();
  }, [fadeAnim])

  return (
    <Animated.View                 // Special animatable View
      style={{
        ...props.style,
        opacity: fadeAnim,         // Bind opacity to animated value
      }}
    >
      {props.children}
    </Animated.View>
  );
}

 const Start = props => {

  function nav(){
      props.navigation.navigate({routeName: 'SecondScreen'});
  }

   
 return (  
        <View style={styles.container}>  
        <FadeInView style={{width: '100%', height: '100%', backgroundColor:'black'}}>
        <ImageBackground source={image} resizeMode="cover" style={styles.image}>
        
        </ImageBackground>
         </FadeInView>
        <View style={styles.butto}> 
        <Button color='red' title="Second Screen" onPress={nav}/>
        </View>
        </View>  
    );  
  
 
}


const styles = StyleSheet.create({  
    container: {  
        flex: 1,  
         flexDirection: 'column',
        justifyContent: 'center',  
        alignItems: 'center',
        backgroundColor: 'black',  
    },  
    tinyLogo: {
    width: 50,
    height: 50,
  },
  image: {
    flex: 1,
    justifyContent: "center",
    width: '100%',
    height: '100%',
  },
  butto: {
      borderColor: 'red',
      position: 'absolute',
      bottom:0,
      right:0,
      left:0, 
      flex: 1,
      justifyContent: "center",   
   },


});  

export default  Start;


